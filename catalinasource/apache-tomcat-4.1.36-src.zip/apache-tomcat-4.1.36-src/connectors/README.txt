Tomcat Connector 

This package contains only the tomcat connector:

- tomcat-utils.jar includes general purpose utilities used in tomcat - buffers, 
thread pools, network code, introspection
- tomcat-coyote.jar includes the base representation of Request, Response and the code common
to all protocols
- tomcat-http11.jar includes the HTTP/1.1 implementation, based on coyote.
- tomcat-jk2.jar includes the Ajp java implementation along with Jk2 java components

